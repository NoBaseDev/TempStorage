package com.example.bookfinder.repository.book.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Book(
    val id: String?,
    val title: String?,
    val author: String?,
    val date: String?,
    val thumb: String?,
    val link: String?
): Parcelable