package com.example.bookfinder.ui.search

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.example.bookfinder.R
import com.example.bookfinder.databinding.FragmentSearchBinding
import com.example.bookfinder.di.Injectable
import jp.wasabeef.recyclerview.animators.LandingAnimator
import javax.inject.Inject

class SearchFragment : Fragment(), Injectable {

    lateinit var binding: FragmentSearchBinding

    @Inject
    lateinit var searchViewModel: SearchViewModel

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        setHasOptionsMenu(true)
        binding = FragmentSearchBinding.inflate(inflater, container, false).apply {
            viewModel = searchViewModel
        }
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner = viewLifecycleOwner
        setupAdapter()
        observeViewModel()
    }

    private fun setupAdapter() {
        binding.rvBook.apply {
            adapter = SearchResultAdapter(searchViewModel)
            addOnScrollListener(
                object: RecyclerView.OnScrollListener() {
                    override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                        super.onScrollStateChanged(recyclerView, newState)
                        if(!recyclerView.canScrollVertically(1)) {
                            searchViewModel.loadMore()
                        }
                    }
                })
            itemAnimator = LandingAnimator(OvershootInterpolator(1f)).apply {
                addDuration = 200
                removeDuration = 100
                moveDuration = 200
                changeDuration = 100
            }
        }
    }

    private fun observeViewModel() {
        searchViewModel.action.observe(viewLifecycleOwner, Observer {
            when(it) {
                is SearchAction.GoDetail -> {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(it.book.link));
                    startActivity(intent)
                }
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_main, menu)
        val searchManager =
            requireActivity().getSystemService(Context.SEARCH_SERVICE) as SearchManager
        (menu.findItem(R.id.menu_search).actionView as SearchView).apply {
            setSearchableInfo(searchManager.getSearchableInfo(requireActivity().componentName))
            setIconifiedByDefault(false)
            imeOptions = EditorInfo.IME_ACTION_DONE;
            maxWidth = Integer.MAX_VALUE
            setOnQueryTextListener(object: SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    query?.let {
                        searchViewModel.clearSearchResult()
                        if(it.isNotBlank()) {
                            searchViewModel.loadBook(it)
                        }
                        clearFocus()
                    }
                    return true
                }
                override fun onQueryTextChange(newText: String?): Boolean {
                    if(newText == "") {
                        onQueryTextSubmit(newText)
                        return true
                    }
                    return false
                }
            })
            setOnCloseListener {
                searchViewModel.clearSearchResult()
                false
            }
        }
    }

}
