package com.example.bookfinder.network.book

import com.example.bookfinder.network.book.model.BookListResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface BookApiService {

    //https://www.googleapis.com/books/v1/volumes?q=%EA%B0%80%EB%82%98%EB%8B%A4&startIndex=1&maxResults=5
    @GET("books/v1/volumes")
    suspend fun getBookList(
        @Query("q") keyword: String,
        @Query("startIndex") index: Int,
        @Query("maxResults") length: Int
    ): Response<BookListResponse>

    companion object {
        const val ENDPOINT = "https://www.googleapis.com"
    }
}