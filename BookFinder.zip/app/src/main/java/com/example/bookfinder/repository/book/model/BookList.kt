package com.example.bookfinder.repository.book.model

data class BookList(val totalCount: Int = 0, val list: List<Book>)