package com.example.bookfinder.repository.book

import com.example.bookfinder.network.DataResult
import com.example.bookfinder.network.book.BookApiService
import com.example.bookfinder.network.book.model.BookListResponse
import com.example.bookfinder.repository.Mapper
import com.example.bookfinder.repository.book.model.BookList
import com.example.bookfinder.utils.dLog
import java.io.IOException
import javax.inject.Inject

class BookRemoteDataSource @Inject constructor(
    private val service: BookApiService,
    private val mapper: Mapper<BookListResponse, BookList>
) {
    suspend fun getBook(keyword: String, index: Int, length: Int): DataResult<BookList> {
        try {
            val response = service.getBookList(keyword, index, length)
            response.takeIf { it.isSuccessful }?.apply {
                body()?.let { body ->
                    return DataResult.Success(mapper.map(body))
                }
            }
            return DataResult.Error(IOException(response.message()))
        } catch (e: Exception) {
            dLog("exception! $e")
            return DataResult.Error(IOException("Failed to get book data.", e))
        }
    }
}