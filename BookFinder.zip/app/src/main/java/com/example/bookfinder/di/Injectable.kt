package com.example.bookfinder.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
