package com.example.bookfinder.repository.book

import javax.inject.Inject

class BookLocalDataSource @Inject constructor(
) {

}