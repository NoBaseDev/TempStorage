package com.example.bookfinder.viewext

import android.graphics.Color
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.widget.TextView
import androidx.databinding.BindingAdapter
import java.text.DecimalFormat

@BindingAdapter("count")
fun TextView.setCount(count: Int?) {
    val cnt = if(count?: 0 < 0) 0 else count
    text = DecimalFormat("검색결과 : ###,### 건").format(cnt)
}

@BindingAdapter(value = ["text", "keyword"])
fun TextView.setHighlight(str: String?, keyword: String?) {
    if(str == null || keyword == null) return
    val sps = SpannableString(str)
    var index = str.indexOf(keyword)
    while(index >= 0) {
        sps.setSpan(ForegroundColorSpan(Color.RED), index, index + keyword.length, 0)
        index = str.indexOf(keyword, index + keyword.length)
    }
    text = sps
}