package com.example.bookfinder.repository.book

import com.example.bookfinder.network.book.model.BookListResponse
import com.example.bookfinder.repository.Mapper
import com.example.bookfinder.repository.book.model.Book
import com.example.bookfinder.repository.book.model.BookList

class BookListMapper : Mapper<BookListResponse, BookList> {
    override fun map(input: BookListResponse): BookList {
        return BookList(input.totalItems?: 0, input.items?.map {
            val vi = it.volumeInfo
            Book(
                it.id,
                vi.title,
                vi.authors?.joinToString(", "),
                vi.publishedDate,
                vi.imageLinks?.thumbnail?: vi.imageLinks?.smallThumbnail,
                vi.infoLink
            )
        }?.let {
            it
        }?: listOf())
    }
}
