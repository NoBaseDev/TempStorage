package com.example.bookfinder.viewext

import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.bookfinder.repository.book.model.Book
import com.example.bookfinder.ui.search.SearchResultAdapter

@BindingAdapter("book")
fun RecyclerView.setBook(result: List<Book>?) {
    (adapter as SearchResultAdapter).submitList(result)
}
