package com.example.bookfinder.viewext

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.MultiTransformation
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions

@BindingAdapter(value=["imageUrl", "radiusDp"], requireAll = false)
fun ImageView.setRoundImage(url: String?, radiusDp: Int?) {
    val metrics = resources.displayMetrics
    val imageUrl = url?: run {
        "https://img.icons8.com/ios/50/000000/book.png"
    }
    val multiOption =  radiusDp?.run {
        val radius = context.resources.displayMetrics.density * (radiusDp?: 0)
        MultiTransformation(CenterCrop(), RoundedCorners(radius.toInt()))
    }?: MultiTransformation(CenterCrop())
    val glide = Glide.with(context)
        .asBitmap()
        .diskCacheStrategy(DiskCacheStrategy.NONE)
        .load(imageUrl)
        .apply(RequestOptions.bitmapTransform(multiOption))
    radiusDp?:run {
        glide.override(metrics.widthPixels, (metrics.widthPixels * 0.5).toInt())
    }
    glide.into(this)
}
