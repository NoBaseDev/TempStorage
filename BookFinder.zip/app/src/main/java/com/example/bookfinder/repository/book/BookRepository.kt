package com.example.bookfinder.repository.book

import com.example.bookfinder.network.DataResult
import com.example.bookfinder.repository.book.model.BookList
import javax.inject.Inject

class BookRepository @Inject constructor(
    private val remoteDataSource: BookRemoteDataSource,
    private val localDataSource: BookLocalDataSource
) {
    suspend fun getBook(keyword: String, index: Int, length: Int): DataResult<BookList> {
        return remoteDataSource.getBook(keyword, index, length)
    }
}