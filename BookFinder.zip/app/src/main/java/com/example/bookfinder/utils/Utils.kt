package com.example.bookfinder.utils

import android.util.Log
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*

const val DLOG_TAG = "BookFinder"

fun dLog(msg: String?) {
    Timber.d(msg)
}


fun getCurrentTime(): String? {
    return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA).run {
        format(System.currentTimeMillis())
    }
}