package com.example.bookfinder.di.module.ui

import com.example.bookfinder.ui.search.SearchFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentModule {

    @ContributesAndroidInjector(modules = [ViewModelModule::class])
    abstract fun contributeSearchFragment(): SearchFragment
}
