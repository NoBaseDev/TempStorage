package com.example.bookfinder.ui.search

import androidx.lifecycle.*
import com.example.bookfinder.network.DataResult
import com.example.bookfinder.repository.book.BookRepository
import com.example.bookfinder.repository.book.model.Book
import com.example.bookfinder.utils.dLog
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import javax.inject.Inject

class SearchViewModel @Inject constructor(
    private val repository: BookRepository
) : ViewModel() {

    private val _dataLoading = MutableLiveData<Boolean>()
    val dataLoading: LiveData<Boolean> = _dataLoading

    private val _book = MutableLiveData<List<Book>>()
    val book: LiveData<List<Book>> = _book

    private val _searchCnt = MutableLiveData(-1)
    val searchCnt: LiveData<Int> = _searchCnt

    private val _keyword = MutableLiveData<String>()
    val keyword: LiveData<String> = _keyword

    private val _action = MutableLiveData<SearchAction>()
    val action: LiveData<SearchAction> = _action

    private var _pagingIndex = 0
    private var _pagingLength = 20

    fun loadMore() {
        keyword.value?.let {
            loadBook(it, true)
        }
    }

    fun loadBook(keyword: String, isMore: Boolean = false) = viewModelScope.launch {
        if(_dataLoading.value == true) return@launch
        _keyword.value = keyword
        if(keyword.isBlank()) {
            clearSearchResult()
            return@launch
        }
        if(searchCnt.value != -1 && searchCnt.value?: 0 <= _pagingIndex) {
            return@launch
        }
        _dataLoading.value = true
        when(val result = repository.getBook(keyword, _pagingIndex, _pagingLength)){
            is DataResult.Success -> {
                result.data.apply {
                    if(!isMore) {
                        _searchCnt.value = totalCount
                    }
                    _book.value = book.value?.toMutableList()?.apply {
                        addAll(list)
                    }?: list
                    _pagingIndex += list.size
                }
            }
        }
        _dataLoading.value = false
    }

    fun clearSearchResult() {
        _pagingIndex = 0
        _searchCnt.value = -1
        _book.value = listOf()
    }


    fun goDetail(book: Book) {
        _action.value = SearchAction.GoDetail(book)
    }

    override fun onCleared() {
        viewModelScope.cancel()
        super.onCleared()
    }
}

class SearchViewModelFactory(
    private val repository: BookRepository
): ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return SearchViewModel(repository) as T
    }
}

sealed class SearchAction {
    class GoDetail(val book: Book): SearchAction()
}