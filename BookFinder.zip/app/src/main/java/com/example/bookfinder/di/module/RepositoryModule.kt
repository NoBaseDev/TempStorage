package com.example.bookfinder.di.module

import com.example.bookfinder.network.book.BookApiService
import com.example.bookfinder.network.book.model.BookListResponse
import com.example.bookfinder.repository.Mapper
import com.example.bookfinder.repository.book.BookListMapper
import com.example.bookfinder.repository.book.BookLocalDataSource
import com.example.bookfinder.repository.book.BookRemoteDataSource
import com.example.bookfinder.repository.book.BookRepository
import com.example.bookfinder.repository.book.model.BookList
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class RepositoryModule() {

    @Singleton
    @Provides
    fun provideBookListMapper(): Mapper<BookListResponse, BookList> {
        return BookListMapper()
    }

    @Singleton
    @Provides
    fun provideBookRepository(remoteDataSource: BookRemoteDataSource, localDataSource: BookLocalDataSource) =
        BookRepository(remoteDataSource, localDataSource)

    @Singleton
    @Provides
    fun provideBookRemoteDataSource(service: BookApiService, mapper: Mapper<BookListResponse, BookList>) =
        BookRemoteDataSource(service, mapper)

    @Singleton
    @Provides
    fun provideBookLocalDataSource() =
        BookLocalDataSource()

}
