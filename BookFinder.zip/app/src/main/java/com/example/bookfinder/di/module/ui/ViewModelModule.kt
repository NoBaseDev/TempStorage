package com.example.bookfinder.di.module.ui

import androidx.lifecycle.ViewModelProvider
import com.example.bookfinder.repository.book.BookRepository
import com.example.bookfinder.ui.search.SearchFragment
import com.example.bookfinder.ui.search.SearchViewModel
import com.example.bookfinder.ui.search.SearchViewModelFactory
import dagger.Module
import dagger.Provides

@Module
class ViewModelModule {

    @Provides
    fun provideSearchViewModel(
        searchFragment: SearchFragment,
        factory: SearchViewModelFactory
    ): SearchViewModel =
        ViewModelProvider(searchFragment, factory).get(SearchViewModel::class.java)

    @Provides
    fun provideSearchViewModelFactory(
        repository: BookRepository
    ): SearchViewModelFactory = SearchViewModelFactory(repository)
}
