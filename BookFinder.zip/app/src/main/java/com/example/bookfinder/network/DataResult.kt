package com.example.bookfinder.network

sealed class DataResult<out R> {
    data class Success<out T>(val data: T): DataResult<T>()
    data class Error(val exception: Exception): DataResult<Nothing>()

    override fun toString(): String {
        return when(this) {
            is Success<*> -> "[Success] $data"
            is Error -> "[Error] $exception"
        }
    }
}