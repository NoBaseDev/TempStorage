package com.example.bookfinder.network.book.model

import com.squareup.moshi.Json

data class BookListResponse(
    @Json(name = "kind") val kind: String?,
    @Json(name = "totalItems") val totalItems: Int?,
    @Json(name = "items") val items: List<BookResponse>?
)

data class BookResponse(
    @Json(name = "id") val id: String?,
    @Json(name = "volumeInfo") val volumeInfo: VolumeInfoResponse
)

data class VolumeInfoResponse(
    @Json(name = "title") val title: String?,
    @Json(name = "authors") val authors: List<String?>?,
    @Json(name = "publishedDate") val publishedDate: String?,
    @Json(name = "infoLink") val infoLink: String?,
    @Json(name = "imageLinks") val imageLinks: ImageLinksResponse?
)

data class ImageLinksResponse(
    @Json(name = "smallThumbnail") val smallThumbnail: String?,
    @Json(name = "thumbnail") val thumbnail: String?
)
