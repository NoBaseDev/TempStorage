package com.example.bookfinder.ui.search

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.bookfinder.databinding.BookItemBinding
import com.example.bookfinder.repository.book.model.Book
import com.example.bookfinder.utils.dLog

class SearchResultAdapter(
    open val viewModel: SearchViewModel
): ListAdapter<Book, RecyclerView.ViewHolder>(BookDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return BookViewHolder(BookItemBinding.inflate(inflater, parent, false))
    }

    override fun onFailedToRecycleView(holder: RecyclerView.ViewHolder): Boolean {
        holder.itemView.animation?.cancel()
        return true
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when(holder) {
            is BookViewHolder -> holder.bind(getItem(position))
        }
    }

    override fun submitList(list: List<Book>?) {
        super.submitList(list)
        dLog("items... $list")
    }

    override fun submitList(list: List<Book>?, commitCallback: Runnable?) {
        super.submitList(list, commitCallback)
        dLog("items... $list")
    }

    class BookDiffCallback : DiffUtil.ItemCallback<Book>() {
        override fun areItemsTheSame(oldItem: Book, newItem: Book): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: Book, newItem: Book): Boolean {
            return oldItem.id == newItem.id
        }
    }

    private inner class BookViewHolder(
        val binding: BookItemBinding
    ): RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Book) {
            binding.item = item
            binding.viewModel = viewModel
            binding.executePendingBindings()
        }
    }
}

